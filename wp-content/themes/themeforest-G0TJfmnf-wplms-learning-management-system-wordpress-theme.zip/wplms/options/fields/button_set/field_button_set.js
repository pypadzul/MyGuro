jQuery(document).ready(function(){
	jQuery('.buttonset').buttonset({items: "button, input[type=radio],input[type=button], input[type=submit]"});
});